<?php

interface Operation
{
    public function Add();
    public function Update();
    public function Delete();
    public function GetAll();
}

?>